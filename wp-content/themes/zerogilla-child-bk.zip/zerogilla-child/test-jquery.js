jQuery(document).ready(function($) {
    console.log('jQuery is available!');
    console.log('jQuery version:', $.fn.jquery);
});
