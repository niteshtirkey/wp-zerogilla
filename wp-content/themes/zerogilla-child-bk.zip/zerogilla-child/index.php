<?php get_header(); ?>

<main class="site-main">
    <div class="container">
        <h1>hiii</h1>
        <?php endwhile; endif; ?>
    </div>
</main>

<?php get_footer(); ?>
